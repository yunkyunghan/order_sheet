function iframe_autoresize(arg)

{
    arg.height = eval(arg.name+".document.body.scrollHeight");
}
